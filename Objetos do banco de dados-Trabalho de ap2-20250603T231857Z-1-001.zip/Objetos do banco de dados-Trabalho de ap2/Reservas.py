class Reservas:
    def __init__(self,fk_id_usuario,fk_id_quarto,tempo_estadia):
        self.fk_id_usuario = fk_id_usuario
        self.fk_id_quarto = fk_id_quarto
        self.tempo_estadia = tempo_estadia
        