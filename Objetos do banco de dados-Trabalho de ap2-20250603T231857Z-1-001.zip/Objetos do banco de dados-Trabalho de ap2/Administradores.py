class Administradores:
    def __init__(self,id_adm,nome,email,cpf):
        self.id_adm = id_adm
        self.nome = nome
        self.email = email
        self.cpf = cpf