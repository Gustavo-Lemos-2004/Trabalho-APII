class Quartos:
    def __init__(self,id_quarto,andar,numero,numero_reserva,chave_cartao,fk_id_hotel,fk_id_usuario):
        self.id_quarto = id_quarto
        self.andar = andar
        self.numero = numero
        self.numero_reserva = numero_reserva
        self.chave_cartao = chave_cartao
        self.fk_id_hotel = fk_id_hotel
        self.fk_id_usuario = fk_id_usuario