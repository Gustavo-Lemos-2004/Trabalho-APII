class Hoteis:
    def __init__(self,id_hotel,nome,cidade,bairro,rua,numero,cnpj,fk_id_adm):
        self.id_hotel = id_hotel
        self.nome = nome
        self.cidade = cidade
        self.bairro = bairro
        self.rua = rua
        self.numero = numero
        self.cnpj = cnpj
        self.fk_id_adm = fk_id_adm