class Usuarios:
    def __init__(self,id_usuario,nome,email,senha,cpf,imagem):
        self.id_usuario = id_usuario
        self.nome = nome
        self.email = email
        self.senha = senha
        self.cpf = cpf
        self.imagem = imagem

